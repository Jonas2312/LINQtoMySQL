﻿namespace ConsoleApp1
{
    public interface IConditionStatement 
    {



    }
}