﻿namespace ConsoleApp1
{
    public interface IBinaryBooleanOperator
    {
    }
}