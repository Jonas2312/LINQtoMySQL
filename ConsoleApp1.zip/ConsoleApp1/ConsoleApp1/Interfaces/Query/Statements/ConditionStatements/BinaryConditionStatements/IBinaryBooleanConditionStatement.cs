﻿using ConsoleApp1.Interfaces.Query.Statements.ConditionStatements.BinaryConditionStatements;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    interface IBinaryBooleanConditionStatement : IBinaryConditionStatement
    {
        IConditionStatement Left { get; set; }
        IConditionStatement Right { get; set; }

        IBinaryBooleanOperator Operator { get; set; }
    }
}
