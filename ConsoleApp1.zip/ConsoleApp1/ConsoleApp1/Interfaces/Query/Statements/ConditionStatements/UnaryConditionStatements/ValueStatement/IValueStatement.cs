﻿namespace ConsoleApp1
{
    public interface IValueStatement
    {

    }
}