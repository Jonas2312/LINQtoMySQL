﻿using ConsoleApp1.Interfaces.Query.Statements.ConditionStatements.BinaryConditionStatements;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class BinaryComparisonStatement : IBinaryComparisonStatement
    {
        public IValueStatement Left { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public IValueStatement Right { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public IBinaryComparisonOperator Operator { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}
