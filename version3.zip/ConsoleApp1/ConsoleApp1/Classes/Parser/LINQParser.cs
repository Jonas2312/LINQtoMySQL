﻿using ConsoleApp1.Classes;
using ConsoleApp1.Classes.QueryStatements;
using ConsoleApp1.Classes.QueryStatements.Statements.ConditionStatements.UnaryConditionStatements.ValueStatement;
using ConsoleApp1.Interfaces.Query.Statements.ConditionStatements.BinaryConditionStatements;
using ConsoleApp1.Statements;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Parser
{
    public class LINQParser : ILINQParser
    {
        public LINQParser(Dictionary<PropertyInfo, PropertyInfo> mapping)
        {

        }

        public Dictionary<PropertyInfo, PropertyInfo> Mapping { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }


        public IQuery GetQuery<TType>(Expression<Func<TType, object[]>> select, Expression<Func<TType, bool>> condition)
        {
            return GetQuery(select.Body, typeof(TType), condition.Body);
        }

        private IQuery GetQuery(Expression select, Type source, Expression condition)
        {
            var Query = new Query
            {
                SelectionStatement = GetSelectStatement(select),
                SourceStatement = GetFromStatement(source),
                ConditionStatement = GetConditionStatement(condition)
            };

            return Query;
        }


        private ISelectionStatement GetSelectStatement(Expression select)
        {
            if (select == null)
                return new SelectionStatement
                {
                    Selections = null
                };

            throw new NotImplementedException();
        }

        private ISourceStatement GetFromStatement(Type type)
        {
            return new SourceStatement
            {
                SourceType = type
            };
        }

        private IConditionStatement GetConditionStatement(Expression condition)
        {
            switch (condition)
            {
                case BinaryExpression binaryExpression:
                    return GetBinaryConditionStatement(binaryExpression);
                case MemberExpression memberExpression:
                    throw new NotImplementedException();
                case ConstantExpression constantExpression:
                    throw new NotImplementedException();
            }
            throw new NotImplementedException();
        }

        private IBinaryConditionStatement GetBinaryConditionStatement(BinaryExpression binaryExpression)
        {
            switch (binaryExpression.NodeType)
            {
                case ExpressionType.And:
                    return new BinaryBooleanConditionStatement
                    {
                        Left = GetConditionStatement(binaryExpression.Left),
                        Right = GetConditionStatement(binaryExpression.Right),
                        Operator = null    // TODO: And
                    };

                case ExpressionType.GreaterThan:
                    return new BinaryComparisonStatement
                    {
                        Left = GetValueStatement(binaryExpression.Left),
                        Right = GetValueStatement(binaryExpression.Right),
                        Operator = null    // TODO: Greater Than
                    };
            }
            throw new NotImplementedException();
        }

        private IValueStatement GetValueStatement(Expression expression)
        {
            switch (expression)
            {
                case MemberExpression memberExpression:
                    return GetMemberStatement(memberExpression);
                case MethodCallExpression methodCallExpression:
                    return GetMethodCallStatement(methodCallExpression);
                case ConstantExpression:
                    throw new NotImplementedException();
            }
            throw new NotImplementedException();
        }

        private IValueStatement GetMemberStatement(MemberExpression memberExpression)
        {
            switch (memberExpression.Type.Name)
            {
                case "list":  // TODO: Type is list
                    return new SubqueryStatement
                    {
                        Query = GetQuery(null, GetGenericTypeParameterFromList(memberExpression.Type), null)
                    };
                case "notlist": // TODO: Type is not collection
                    return new PropertyStatement
                    {
                        PropertyInfo = (PropertyInfo) memberExpression.Member
                    };
            }
            throw new NotImplementedException();
        }

        private IValueStatement GetMethodCallStatement(MethodCallExpression methodCallExpression)
        {
            switch(methodCallExpression.Method.Name)
            {
                case "Where":
                    return GetWhereMethodCallStatement(methodCallExpression.Arguments);
                case "Count":
                    switch (methodCallExpression.Arguments.Count)
                    {
                        case 1:
                            return GetCountMethodCallStatement(methodCallExpression.Arguments);
                        case 2:
                            return GetWhereCountMethodCallStatement(methodCallExpression.Arguments);
                        default:
                            throw new NotImplementedException();
                    }

            }
            throw new NotImplementedException();
        }

        private IValueStatement GetWhereCountMethodCallStatement(ReadOnlyCollection<Expression> arguments)
        {
            return new UnaryStatement
            {
                ValueStatement = GetWhereMethodCallStatement(arguments),
                MethodType = null // TODO: IUnaryMethodType Count
            };
        }

        private IValueStatement GetCountMethodCallStatement(ReadOnlyCollection<Expression> arguments)
        {
            return new UnaryStatement
            {
                ValueStatement = GetValueStatement(arguments[0]),
                MethodType = null // TODO: IUnaryMethodType Count
            };
        }

      

        private ISubqueryStatement GetWhereMethodCallStatement(ReadOnlyCollection<Expression> arguments)
        {
            return new SubqueryStatement
            {
                Query = GetQuery(null, GetGenericTypeParameterFromList(arguments[0].Type), arguments[1])
            };
        }

        private Type GetGenericTypeParameterFromList(Type type)
        {
            return type.GenericTypeArguments[0];
        }


    }
}
