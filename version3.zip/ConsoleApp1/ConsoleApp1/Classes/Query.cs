﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Classes
{
    class Query : IQuery
    {

        public ISourceStatement SourceStatement { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public ISelectionStatement SelectionStatement { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public IConditionStatement ConditionStatement { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public string Alias { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}
