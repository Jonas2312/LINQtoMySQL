﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Classes.QueryStatements
{
    class SelectionStatement : ISelectionStatement
    {
        public List<PropertyInfo> Selections { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}
