﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class BinaryBooleanConditionStatement : IBinaryBooleanConditionStatement
    {
        public IConditionStatement Left { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public IConditionStatement Right { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public IBinaryBooleanOperator Operator { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}
