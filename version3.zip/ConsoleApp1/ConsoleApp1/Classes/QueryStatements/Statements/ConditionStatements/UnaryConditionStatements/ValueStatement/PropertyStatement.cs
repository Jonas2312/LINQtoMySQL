﻿using ConsoleApp1.Statements;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Classes.QueryStatements.Statements.ConditionStatements.UnaryConditionStatements.ValueStatement
{
    class PropertyStatement : IPropertyStatement
    {
        public PropertyInfo PropertyInfo { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}
