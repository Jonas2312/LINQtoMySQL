﻿using ConsoleApp1.Interfaces.Query.Operator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class UnaryStatement : IUnaryStatement
    {
        public IValueStatement ValueStatement { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public IUnaryMethodType MethodType { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}
