﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Parser
{
    interface ILINQParser
    {
        public Dictionary<PropertyInfo, PropertyInfo> Mapping { get; set; }
        public IQuery GetQuery<TType>(Expression<Func<TType, object[]>> select,  Expression<Func<TType, bool>> condition);
    }
}
