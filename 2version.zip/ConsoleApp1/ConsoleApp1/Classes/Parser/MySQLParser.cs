﻿using ConsoleApp1.Interfaces.Query.Statements.ConditionStatements.BinaryConditionStatements;
using ConsoleApp1.Parser;
using ConsoleApp1.Statements;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Classes.Parser
{
    class MySQLParser : IMySQLParser
    {
        public Dictionary<PropertyInfo, PropertyInfo> Mapping { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public string GetMySQLString(IQuery query, BubbleInformation bubbleInformation = null)
        {
            var selectString = EvaluateSelectionStatement(query.SelectionStatement);
            var fromString = EvaluateSourceStatement(query.SourceStatement, bubbleInformation);
            var whereString = EvaluateConditionStatement(query.ConditionStatement, bubbleInformation);

            var MySQLBubbleUpwardsString = GetBubbleUpwardsString(bubbleInformation);
            var MappingString = GetMapping(bubbleInformation);

            var resultString = selectString + fromString + whereString;

            return resultString;
        }

        private string GetMapping(BubbleInformation bubbleInformation)
        {
            if (bubbleInformation.Count <= 1)
                return string.Empty;

            var previousSource = bubbleInformation.ToList()[bubbleInformation.Count - 2];
            var currentSource = bubbleInformation.ToList()[bubbleInformation.Count - 1];

            var previousSourceTableName = previousSource.Key.Name;  // TODO: Get table name
            var currentSourceTableName = currentSource.Key.Name;  // TODO: Get table name

            var mappedColumnName = Mapping[previousSource.Key.GetProperty("id")].Name;// TODO: Get column name of property

            return previousSourceTableName + ".id = " + currentSourceTableName + "." + mappedColumnName;
        }

        private string GetBubbleUpwardsString(BubbleInformation bubbleInformation)
        {
            var resultString = string.Empty;
            for(int i = 0; i < bubbleInformation.Count; i++)
            {
                resultString += " and ";

                var pairs = bubbleInformation.ToList();

                var aliasName = pairs[i].Value;
                var tableName = pairs[i].Key.Name; // TODO: Get table name

                resultString += tableName + ".id = " + aliasName + ".id";                    
            }
            return resultString;
        }

        private string EvaluateSelectionStatement(ISelectionStatement selectionStatement)
        {
            throw new NotImplementedException();
        }

        private string EvaluateSourceStatement(ISourceStatement sourceStatement, BubbleInformation bubbleInformation = null)
        {
            if (bubbleInformation == null)
                bubbleInformation = new BubbleInformation();
            var alias = GenerateRandomAlias();
            bubbleInformation.Add(sourceStatement.SourceType, alias);

            string resultString = "FROM ";
            for(int i = 0; i < bubbleInformation.Count; i++)
            {
                resultString += bubbleInformation.ToList()[i].Key.Name; // TODO: get tablename from type
                if (i < bubbleInformation.Count - 1)
                {
                    resultString += ", ";
                }
                else
                {
                    resultString += " as " + alias;
                }
            }
            return resultString;
        }

        private string EvaluateConditionStatement(IConditionStatement conditionStatement, BubbleInformation bubbleInformation)
        {
            string resultString = "WHERE ";
            switch (conditionStatement)
            {
                case IBinaryConditionStatement binaryConditionStatement:
                    return EvaluateBinaryConditionStatement(binaryConditionStatement, bubbleInformation);
            }
            throw new NotImplementedException();
        }

        private string EvaluateBinaryConditionStatement(IBinaryConditionStatement binaryConditionStatement, BubbleInformation bubbleInformation)
        {
            switch (binaryConditionStatement)
            {
                case IBinaryBooleanConditionStatement binaryBooleanConditionStatement:
                    return EvaluateBinaryBooleanConditionStatement(binaryBooleanConditionStatement);
                case IBinaryComparisonStatement binaryComparisonStatement:
                    return EvaluateBinaryComparisonStatement(binaryComparisonStatement, bubbleInformation);
            }
            throw new NotImplementedException();
        }

        private string EvaluateBinaryComparisonStatement(IBinaryComparisonStatement binaryComparisonStatement, BubbleInformation bubbleInformation)
        {
            var resultString = EvaluateValueStatement(binaryComparisonStatement.Left, bubbleInformation);
            resultString += EvaluateBinaryComparisonOperator(binaryComparisonStatement.Operator);
            resultString += EvaluateValueStatement(binaryComparisonStatement.Right, bubbleInformation);
            return resultString;
        }

        private string EvaluateBinaryComparisonOperator(IBinaryComparisonOperator comparisonOperator)
        {
            switch (comparisonOperator)
            {
                
            }
            throw new NotImplementedException();
        }

        private string EvaluateValueStatement(IValueStatement valueStatement, BubbleInformation bubbleInformation)
        {
            switch (valueStatement)
            {
                case ISubqueryStatement subqueryStatement:
                    return EvaluateSubqueryStatement(subqueryStatement, bubbleInformation);
            }
            throw new NotImplementedException();
        }

        private string EvaluateSubqueryStatement(ISubqueryStatement subqueryStatement, BubbleInformation bubbleInformation)
        {
            var resultString = "(";

            resultString += GetMySQLString(subqueryStatement.Query, bubbleInformation);
            resultString += ")";
            return resultString;
        }

        private string EvaluateBinaryBooleanConditionStatement(IBinaryBooleanConditionStatement binaryBooleanConditionStatement)
        {
            throw new NotImplementedException();
        }

        private string GenerateRandomAlias()
        {
            return String.Concat(Guid.NewGuid().ToString("N").Select(c => (char)(c + 17)));
        }
    }
}
