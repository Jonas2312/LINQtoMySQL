﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public interface IQuery
    {
        public ISourceStatement SourceStatement { get; set; }
        public ISelectionStatement SelectionStatement { get; set; }
        public IConditionStatement ConditionStatement { get; set; }

        public string Alias { get; set; }
    }
}
