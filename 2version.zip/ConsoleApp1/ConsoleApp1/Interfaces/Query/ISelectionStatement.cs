﻿using System.Collections.Generic;
using System.Reflection;

namespace ConsoleApp1
{
    public interface ISelectionStatement
    {
        List<PropertyInfo> Selections { get; set; }
    }
}