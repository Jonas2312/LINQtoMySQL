﻿using System;

namespace ConsoleApp1
{
    public interface ISourceStatement
    {
        Type SourceType { get; set; }
    }
}