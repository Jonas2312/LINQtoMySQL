﻿namespace ConsoleApp1
{
    public interface IBinaryComparisonOperator
    {
    }
}