﻿using ConsoleApp1.Classes.Parser;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Parser
{
    interface IMySQLParser
    {
        public Dictionary<PropertyInfo, PropertyInfo> Mapping { get; set; }
        public string GetMySQLString(IQuery query, BubbleInformation bubbleInformation = null);
    }
}
